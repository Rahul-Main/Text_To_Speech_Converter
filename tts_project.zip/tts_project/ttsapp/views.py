from django.shortcuts import render
from gtts import gTTS
import os
from django.conf import settings
from django.http import FileResponse

def home(request):
    if request.method == "POST":
        txt = request.POST.get("txt")
        language = request.POST.get("language", "en")  # Default to English
        print(txt, language)

        # Generate speech with selected language
        tts = gTTS(text=txt, lang=language)

        tts_dir = os.path.join(settings.MEDIA_ROOT, "tts")
        os.makedirs(tts_dir, exist_ok=True)
        fpath = os.path.join(tts_dir, "sound.mp3")
        tts.save(fpath)

        return FileResponse(open(fpath, "rb"), as_attachment=True, filename="sound.mp3")

    return render(request, "home.html")
